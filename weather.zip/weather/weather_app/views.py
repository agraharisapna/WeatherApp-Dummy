from django.shortcuts import render
import requests
import json

api_key = '9f38054a9160a7fef9a8b51f456b2e71'

def fetch_weather_data(city):
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&units=imperial&APPID={api_key}"
    print(url)
    response = requests.get(url)
    return response.json()

# city = input("enter weather: ")
# fetch_weather_data(city)

def display_weather_data(weather_data):
    
    if 'code' in weather_data and weather_data['code'] == '404':
        print("City not found. Please try again.")
        
    else:
        coordinate = weather_data['coord']
        main_data = weather_data['main']
        country_code = weather_data['sys']
        coord = coordinate['lon']
        code = country_code['country']
        temperature = main_data['temp'] - 273.15
        humidity = main_data['humidity']
        city = weather_data['name']
        weather_description = weather_data['weather'][0]['description']


        print(f"Coordinate: {coord}")
        print(f"Country: {code}")
        print(f"Temperature: {temperature:.2f}°C")
        print(f"Humidity: {humidity}%")
        print(f"City: {city}")
        print(f"Weather description: {weather_description.capitalize()}")
    
# def main():
#     city = input("Enter the name of the city: ")
#     weather_data = fetch_weather_data(city)
#     display_weather_data(weather_data)
           
# if __name__ == "__main__":
#     main()

# Create your views here.
def index(request):
    if request.method == "POST":
        city = request.POST.get("city", '')
        weather_data = fetch_weather_data(city)
        display_weather_data(weather_data)
        return render(request, 'index.html', {'weather_data': weather_data})
    else:
        return render(request, 'index.html')