from django.urls import path
from . import views 

from weather_app.views import index

urlpatterns = [
    path('', views.index, name='home'),
]